from typing import Protocol
from rag.app.context import Context
from rag.trace.trace_bus import TraceBus


class PipelineStage(Protocol):
    def get_name(self) -> str:
        """
        Get the stage name for trace logs.
        
        Returns:
            Stage name
        """
        ...

    def run(self, context: Context, trace_bus: TraceBus) -> None:
        """
        Execute the stage.
        
        Args:
            context: Pipeline state
            trace_bus: Log system
        """
        ...






