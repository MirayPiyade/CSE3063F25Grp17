from typing import Protocol, Optional, List
from rag.answer.answer import Answer
from rag.retrieval.hit import Hit


class AnswerAgent(Protocol):
    def generate_answer(self, hits: List[Hit], query: str) -> Optional[Answer]:
        """
        Generate an answer from hits and query.
        
        Args:
            hits: List of retrieved hits
            query: The query string
            
        Returns:
            Generated answer or None
        """
        ...






