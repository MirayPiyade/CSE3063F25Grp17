from typing import Protocol, List, Any
from rag.retrieval.hit import Hit


class Reranker(Protocol):
    def rerank(self, terms: List[str], hits: List[Hit], config: Any) -> List[Hit]:
        """
        Rerank hits based on terms and configuration.
        
        Args:
            terms: List of query terms
            hits: List of hits to rerank
            config: Optional configuration object
            
        Returns:
            Reranked list of hits
        """
        ...






