from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from pathlib import Path
import re
from typing import Pattern
from rag.intents.intent import Intent
from rag.intents.intent_detector import IntentDetector
from rag.utils.json_utils import JsonUtils


@dataclass
class Rule:
    intent: Intent
    priority: int
    keywords: List[str]
    bonus_keywords: List[str]
    required_any: List[str]
    forbidden: List[str]
    patterns: List[Pattern[str]]
    min_score: float


class RuleIntentDetector(IntentDetector):
    """
    Smarter rule-based intent detector.

    Backwards compatible with the initial Iteration 1 behaviour, but supports
    richer configuration in intents.yaml:

    - keywords: mandatory base keywords (same as before)
    - bonusKeywords: optional, higher-weight keywords
    - requiredAny: optional, at least one of these must appear for the rule to apply
    - forbidden: optional, if any appears the rule is skipped
    - patterns: optional, regex patterns (case-insensitive) that boost the score
    - minScore: optional, minimum score required for this intent to be accepted
    """

    def __init__(self, yaml_path: str) -> None:
        self.rules: List[Rule] = []
        raw: str = Path(yaml_path).read_text(encoding="utf-8")
        root: Dict[str, Any] = JsonUtils.expect_object(
            JsonUtils.parse(raw),
            "intents.yaml must contain a JSON object",
        )

        for key, value in root.items():
            key_str: str = str(key)
            intent: Intent = self._parse_intent(key_str)
            spec: Dict[str, Any] = JsonUtils.expect_object(
                value,
                f"Intent definition for {key_str} must be an object",
            )

            priority: int = int(spec.get("priority", float("inf")))

            # Base keywords (required)
            keywords_node: List[Any] = JsonUtils.expect_array(
                spec.get("keywords"),
                f"Intent {key_str} is missing keywords",
            )
            keywords: List[str] = [str(kw).lower() for kw in keywords_node]

            # Optional smarter rule fields
            bonus_keywords: List[str] = []
            bonus_node: Any = spec.get("bonusKeywords")
            if bonus_node is not None:
                bonus_arr: List[Any] = JsonUtils.expect_array(
                    bonus_node,
                    f"Intent {key_str} bonusKeywords must be an array",
                )
                bonus_keywords = [str(kw).lower() for kw in bonus_arr]

            required_any: List[str] = []
            required_node: Any = spec.get("requiredAny")
            if required_node is not None:
                required_arr: List[Any] = JsonUtils.expect_array(
                    required_node,
                    f"Intent {key_str} requiredAny must be an array",
                )
                required_any = [str(kw).lower() for kw in required_arr]

            forbidden: List[str] = []
            forbidden_node: Any = spec.get("forbidden")
            if forbidden_node is not None:
                forbidden_arr: List[Any] = JsonUtils.expect_array(
                    forbidden_node,
                    f"Intent {key_str} forbidden must be an array",
                )
                forbidden = [str(kw).lower() for kw in forbidden_arr]

            patterns: List[Pattern[str]] = []
            patterns_node: Any = spec.get("patterns")
            if patterns_node is not None:
                patterns_arr: List[Any] = JsonUtils.expect_array(
                    patterns_node,
                    f"Intent {key_str} patterns must be an array",
                )
                for pattern_str in patterns_arr:
                    compiled: Pattern[str] = re.compile(
                        str(pattern_str), re.IGNORECASE
                    )
                    patterns.append(compiled)

            min_score: float = 1.0
            min_score_node: Any = spec.get("minScore")
            if min_score_node is not None:
                min_score = JsonUtils.expect_number(
                    min_score_node,
                    f"Intent {key_str} minScore must be a number",
                )

            self.rules.append(
                Rule(
                    intent=intent,
                    priority=priority,
                    keywords=keywords,
                    bonus_keywords=bonus_keywords,
                    required_any=required_any,
                    forbidden=forbidden,
                    patterns=patterns,
                    min_score=min_score,
                )
            )

        # Keep deterministic order by priority (lower is better)
        self.rules.sort(key=lambda r: r.priority)

    def detect(self, q: Optional[str]) -> Intent:
        if q is None or not q.strip():
            return Intent.Unknown

        text: str = q.lower()
        best_intent: Intent = Intent.Unknown
        best_score: float = 0.0
        best_priority: float = float("inf")
        best_min_score: float = 1.0

        for rule in self.rules:
            # Apply required / forbidden constraints first
            if rule.required_any:
                if not any(req in text for req in rule.required_any):
                    continue
            if rule.forbidden and any(block in text for block in rule.forbidden):
                continue

            # Base scoring
            base_matches: int = sum(1 for kw in rule.keywords if kw in text)
            bonus_matches: int = sum(1 for kw in rule.bonus_keywords if kw in text)
            pattern_matches: int = 0
            for pattern in rule.patterns:
                if pattern.search(text):
                    pattern_matches += 1

            # Weight different signal types; these constants are simple but
            # enough to express "smarter" behaviour.
            score: float = (
                base_matches * 1.0 + bonus_matches * 2.0 + pattern_matches * 3.0
            )

            if score <= 0.0:
                continue

            # Prefer higher score; tie-breaker: lower (better) priority
            if score > best_score or (
                score == best_score and rule.priority < best_priority
            ):
                best_score = score
                best_priority = float(rule.priority)
                best_intent = rule.intent
                best_min_score = rule.min_score

        # Confidence gating: if no rule is strong enough, fall back to Unknown.
        if best_intent is Intent.Unknown:
            return Intent.Unknown
        if best_score < best_min_score:
            return Intent.Unknown

        return best_intent

    def _parse_intent(self, value: str) -> Intent:
        try:
            return Intent[value]
        except KeyError:
            return Intent.Unknown