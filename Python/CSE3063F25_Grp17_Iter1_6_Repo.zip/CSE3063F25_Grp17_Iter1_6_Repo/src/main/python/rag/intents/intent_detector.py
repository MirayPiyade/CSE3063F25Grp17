from typing import Protocol
from rag.intents.intent import Intent


class IntentDetector(Protocol):
    def detect(self, question: str) -> Intent:
        """
        Detect the intent from a question.
        
        Args:
            question: The question string
            
        Returns:
            The detected Intent
        """
        ...






