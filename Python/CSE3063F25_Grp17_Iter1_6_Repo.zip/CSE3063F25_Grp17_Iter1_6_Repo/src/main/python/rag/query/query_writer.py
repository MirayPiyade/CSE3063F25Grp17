from typing import Protocol, List
from rag.intents.intent import Intent


class QueryWriter(Protocol):
    def write(self, question: str, intent: Intent) -> List[str]:
        """
        Write query terms from a question and intent.
        
        Args:
            question: The question string
            intent: The detected intent
            
        Returns:
            List of query terms
        """
        ...






