import time
from typing import Final


def now() -> int:
    """Get current time in milliseconds."""
    return int(time.time() * 1000)






