"""
Main entry point for the RAG CLI.
Can be run with: python -m rag.app.rag_cli
"""
from rag.app.rag_cli import main

if __name__ == "__main__":
    main()



